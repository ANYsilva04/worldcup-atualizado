﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Worldcup
{
    internal class Program
    {
        static void Main(string[] args)

        {
            Console.WriteLine(" |------------------------------------------Mundial 2022-----------------------------------------|");
            Console.WriteLine("  _________________         _________________         _________________         _________________ ");
            Console.WriteLine(" |     Group  A    |       |     Group   B   |       |     Group C     |       |     Group D     |");
            Console.WriteLine(" |-----------------|       |-----------------|       |-----------------|       |-----------------|");
            Console.WriteLine(" |      Qatar      |       |    Inglaterra   |       |   Argentina     |       |      França     |");
            Console.WriteLine(" |     Ecuador     |       |  Estados unidos |       |    Polónia      |       |    Austrália    |");
            Console.WriteLine(" |     Senegal     |       |       Irã       |       |     México      |       |     Tunísia     |");
            Console.WriteLine(" |     Holanda     |       |      Gales      |       |  Arábia Saudita |       |    Diniamarca   |");
            Console.WriteLine(" |_________________|       |_________________|       |_________________|       |_________________|");
            Console.WriteLine("  _________________         _________________         _________________         _________________ ");
            Console.WriteLine(" |     Group  E    |       |     Group  F    |       |     Group G     |       |     Group H     |");
            Console.WriteLine(" |-----------------|       |-----------------|       |-----------------|       |-----------------|");
            Console.WriteLine(" |      Japão      |       |    Marrocos     |       |      Brasil     |       |  Coreia do sul  |");
            Console.WriteLine(" |     Espanha     |       |     Croácia     |       |      Suíça      |       |     Portugal    |");
            Console.WriteLine(" |    Alemanha     |       |     Béligica    |       |      Camarõs    |       |     Uruguai     |");
            Console.WriteLine(" |    Costa Rica   |       |      Canadá     |       |      Sérvia     |       |      Gana       |");
            Console.WriteLine(" |_________________|       |_________________|       |_________________|       |_________________|");
            Console.ReadLine();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo A:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     1 Rodada: Qatar vs Senegal");

            Random rnd = new Random();

            int gqatar = rnd.Next(0, 3);

            Random rnd2 = new Random();

            int gsenegal = rnd2.Next(0, 6);


            Console.WriteLine("     Qatar: " + gqatar + " - " + gsenegal + " :Senegal");
            if (gqatar > gsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Qatar venceu!\n");
            }
            else if (gqatar == gsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gqatar < gsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Senegal venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;





            Console.WriteLine("\n\n     2 Rodada: Equador vs Holanda");

            Random rnd3 = new Random();

            int gequador = rnd3.Next(0, 3);

            Random rnd4 = new Random();

            int gholanda = rnd4.Next(0, 6);


            Console.WriteLine("     Equador: " + gequador + " - " + gholanda + " :Holanda");
            if (gequador > gholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Equador venceu!\n");
            }
            else if (gequador == gholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gequador < gholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Holanda venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     3 Rodada: Qatar vs Senegal");

            Random rnd5 = new Random();

            int ggqatar = rnd5.Next(0, 2);

            Random rnd6 = new Random();

            int ggholanda = rnd6.Next(0, 5);


            Console.WriteLine("     Qatar: " + ggqatar + " - " + ggholanda + " :Holanda");
            if (ggqatar > ggholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Qatar venceu!\n");
            }
            else if (ggqatar == ggholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggqatar < ggholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Holanda venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     4 Rodada: Equador vs Senegal");


            Random rnd7 = new Random();

            int ggequador = rnd7.Next(0, 4);

            Random rnd8 = new Random();

            int ggsenegal = rnd8.Next(0, 3);


            Console.WriteLine("     Equador: " + ggequador + " - " + ggsenegal + " :Senegal");
            if (ggequador > ggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Equador venceu!\n");
            }
            else if (ggequador == ggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggequador < ggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Senegal venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;





            Console.WriteLine("\n\n     5 Rodada: Holanda vs Senegal");

            Random rnd9 = new Random();

            int gggholanda = rnd9.Next(0, 4);

            Random rnd10 = new Random();

            int gggsenegal = rnd10.Next(0, 2);


            Console.WriteLine("     Holanda: " + gggholanda + " - " + gggsenegal + " :Senegal");
            if (gggholanda > gggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Holanda venceu!\n");
            }
            else if (gggholanda == gggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gggholanda < gggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Senegal venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;





            Console.WriteLine("\n\n     6 Rodada: Qatar vs Equador");

            Random rnd11 = new Random();

            int gggqatar = rnd11.Next(0, 2);

            Random rnd12 = new Random();

            int gggequador = rnd12.Next(0, 4);


            Console.WriteLine("     Qatar: " + gggqatar + " - " + gggequador + " :Equador");
            if (gggqatar > gggequador)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Qatar venceu!\n");
            }
            else if (gggqatar == gggequador)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gggqatar < gggequador)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Equador venceu!");

            }


            Console.ForegroundColor = ConsoleColor.White;
            int gQ = gggqatar + ggqatar + gqatar;
            Console.WriteLine("\n\n\n\n __________________________________________________ ");
            Console.WriteLine(" |      Group  A      | V | E | D | GM | GD | Pts | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |      Qatar         |   |   |   | " + gQ + "  |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Ecuador        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Senegal        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Holanda        |   |   |   |    |    |     | ");
            Console.WriteLine(" |____________________|___|___|___|____|____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();



            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: B");
            Console.ForegroundColor = ConsoleColor.White;
        
            



            Console.WriteLine("\n\n     1 Rodada: Inglaterra vs Estados Unidos");

            Random rnd13 = new Random();

            int inglaterra = rnd13.Next(0, 4);

            Random rnd14 = new Random();

            int estadosunidos = rnd14.Next(0, 2);


            Console.WriteLine("     Inglaterra: " + inglaterra + " - " + estadosunidos + " :Estados Unidos");
            if (inglaterra > estadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Inglaterra venceu!\n");
            }
            else if (inglaterra == estadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (inglaterra < estadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Estados Unidos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
            



            Console.WriteLine("\n\n     2 Jogo: Irã vs País de Gales");

            Random rnd15 = new Random();

            int ira = rnd15.Next(0, 3);

            Random rnd16 = new Random();

            int paisgales = rnd16.Next(0, 6);


            Console.WriteLine("     Irã: " + ira + " - " + paisgales + " :País de Gales");
            if (ira > paisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Irã venceu!\n");
            }
            else if (ira == paisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ira < paisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     País de Gales venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
        



            Console.WriteLine("\n\n     3 Jogo: Estados Unidos vs Irã");

            Random rnd17 = new Random();

            int gestadosunidos = rnd17.Next(0, 4);

            Random rnd18 = new Random();

            int gira = rnd18.Next(0, 4);


            Console.WriteLine("     Irã: " + gira + " - " + gestadosunidos + " :Estados Unidos");
            if (gira > gestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Irã venceu!\n");
            }
            else if (gira == gestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gira < gestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Estados Unidos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
       



            Console.WriteLine("\n\n     4 Jogo: Inglaterra vs País de Gales");

            Random rnd19 = new Random();

            int ginglaterra = rnd19.Next(0, 5);

            Random rnd20 = new Random();

            int gpaisgales = rnd20.Next(0, 2);


            Console.WriteLine("     Inglaterra: " + ginglaterra + " - " + gpaisgales + " :País de Gales");
            if (ginglaterra > gpaisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Inglaterra venceu!\n");
            }
            else if (ginglaterra == gpaisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ginglaterra < gpaisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     País de Gales venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
          



            Console.WriteLine("\n\n     5 Jogo: Estados Unidos vs País de Gales");

            Random rnd22 = new Random();

            int ggpaisdegales = rnd22.Next(0, 3);

            Random rnd23 = new Random();

            int ggestadosunidos = rnd23.Next(0, 3);


            Console.WriteLine("     País de Gales: " + ggpaisdegales + " - " + ggestadosunidos + " :Estados Unidos");
            if (ggpaisdegales > ggestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     País de Gales venceu!\n");
            }
            else if (ggpaisdegales == ggestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggpaisdegales < ggestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Estados Unidos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;
       


            Console.WriteLine("\n\n     6 Jogo: Inglaterra vs País de Gales");

            Random rnd24 = new Random();

            int ggginglaterra = rnd24.Next(0, 7);

            Random rnd25 = new Random();

            int gggira = rnd25.Next(0, 3);


            Console.WriteLine("     Inglaterra: " + ggginglaterra + " - " + gggira + " :Irã");
            if (ggginglaterra > gggira)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Inglaterra venceu!\n");
            }
            else if (ggginglaterra == gggira)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggginglaterra < gggira)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     irã venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            
            Console.WriteLine("\n\n\n\n __________________________________________________ ");
            Console.WriteLine(" |      Group  A      | V | E | D | GM | GD | Pts | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |      Qatar         |   |   |        |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Ecuador        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Senegal        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Holanda        |   |   |   |    |    |     | ");
            Console.WriteLine(" |____________________|___|___|___|____|____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();



            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: C");
            Console.ForegroundColor = ConsoleColor.White;
            
            Console.WriteLine("\n\n     1 Rodada: Argentina vs Arábia Saudita ");

            Random rnd26 = new Random();

            int argentina = rnd26.Next(0, 4);

            Random rnd27 = new Random();

            int arabia = rnd27.Next(0, 2);


            Console.WriteLine("     Argentina: " + argentina + " - " + arabia + " :Arábia Saudita");
            if (argentina > arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Argentina venceu!\n");
            }
            else if (argentina == arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (argentina < arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Arábia Saudita venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


       
            Console.WriteLine("\n\n     2 Rodada: Mexico vs Polónia ");

            Random rnd28 = new Random();

            int mexico = rnd28.Next(0, 3);

            Random rnd29 = new Random();

            int polonia = rnd29.Next(0, 4);


            Console.WriteLine("     Mexico: " + mexico + " - " + polonia + " :Polónia");
            if (mexico > polonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Mexico venceu!\n");
            }
            else if (mexico == polonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (mexico < polonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Polónia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


          
            Console.WriteLine("\n\n     3 Rodada: Polónia vs Arábia Saudita ");

            Random rnd30 = new Random();

            int gpolonia = rnd30.Next(0, 4);

            Random rnd31 = new Random();

            int garabia = rnd31.Next(0, 3);


            Console.WriteLine("     Polónia: " + gpolonia + " - " + garabia + " :Arábia Saudita");
            if (gpolonia > garabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Polónia venceu!\n");
            }
            else if (gpolonia == arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gpolonia < arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Arábia Saudita venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     4 Rodada: Argentina vs Mexico ");

            Random rnd33 = new Random();

            int gargentina = rnd33.Next(0, 4);

            Random rnd34 = new Random();

            int gmexico = rnd34.Next(0, 3);


            Console.WriteLine("     Argentina: " + gargentina + " - " + gmexico + " :Mexico");
            if (gargentina > gmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Argentina venceu!\n");
            }
            else if (gargentina == gmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gargentina < gmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Mexico venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


     
            Console.WriteLine("\n\n     5 Rodada: Argentina vs Polónia ");

            Random rnd35 = new Random();

            int ggargentina = rnd35.Next(0, 4);

            Random rnd36 = new Random();

            int ggpolonia = rnd36.Next(0, 3);


            Console.WriteLine("     Argentina: " + ggargentina + " - " + ggpolonia + " :polónia");
            if (ggargentina > ggpolonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Argentina venceu!\n");
            }
            else if (ggargentina == ggpolonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggargentina < ggpolonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Plónia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     6 Rodada: Arábia Saudita vs Mexico ");

            Random rnd37 = new Random();

            int ggarabia = rnd37.Next(0, 3);

            Random rnd38 = new Random();

            int ggmexico = rnd38.Next(0, 3);


            Console.WriteLine("     Arábia Saudita: " + ggarabia + " - " + ggmexico + " :Mexico");
            if (ggarabia > ggmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Arábia Saudita venceu!\n");
            }
            else if (ggarabia == ggmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggarabia < ggmexico)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Mexico venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(" \n\n\n\n__________________________________________________ ");
            Console.WriteLine(" |      Group  A      | V | E | D | GM | GD | Pts | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |      Qatar         |   |   |        |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Ecuador        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Senegal        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Holanda        |   |   |   |    |    |     | ");
            Console.WriteLine(" |____________________|___|___|___|____|____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();


            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: D");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     1 Rodada: Dinamarca vs Tunísia ");

            Random rnd39 = new Random();

            int dinamarca = rnd39.Next(0, 3);

            Random rnd40 = new Random();

            int tunisia = rnd40.Next(0, 2);

            Console.WriteLine("     Dinamarca: " + dinamarca + " - " + tunisia + " :Tunísia");
            if (dinamarca > tunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Dinamarca venceu!\n");
            }
            else if (dinamarca == tunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (dinamarca < tunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Tunísia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     2 Rodada: Austrália vs França ");

            Random rnd41 = new Random();

            int franca = rnd41.Next(0, 6);

            Random rnd42 = new Random();

            int australia = rnd42.Next(0, 3);


            Console.WriteLine("     Austrália: " + australia + " - " + franca + " :França");
            if (australia > franca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Austrália venceu!\n");
            }
            else if (australia == franca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (australia < franca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     França venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     3 Rodada: Austrália vs Tunísia ");

            Random rnd43 = new Random();

            int gtunisia = rnd43.Next(0, 4);

            Random rnd44 = new Random();

            int gaustralia = rnd44.Next(0, 3);


            Console.WriteLine("     Austrália: " + gaustralia + " - " + gtunisia + " :Tunísia");
            if (gaustralia > gtunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Austrália venceu!\n");
            }
            else if (gaustralia == gtunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gaustralia < gtunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Tunísia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     4 Rodada: Dinamarca vs França ");

            Random rnd45 = new Random();

            int gfranca = rnd45.Next(0, 4);

            Random rnd46 = new Random();

            int gdinamarca = rnd46.Next(0, 3);


            Console.WriteLine("     Dinamarca: " + gdinamarca + " - " + gfranca + " :França");
            if (gdinamarca > gfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Dinamarca venceu!\n");
            }
            else if (gdinamarca == gfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gdinamarca < gfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     França venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     5 Rodada: Tunísia vs França ");

            Random rnd47 = new Random();

            int ggfranca = rnd47.Next(0, 4);

            Random rnd48 = new Random();

            int ggtunisia = rnd48.Next(0, 2);


            Console.WriteLine("     Tunísia: " + ggtunisia + " - " + ggfranca + " :França");
            if (ggtunisia > ggfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Tunísia venceu!\n");
            }
            else if (ggtunisia == ggfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggtunisia < franca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     França venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     6 Rodada: Austrália vs Dinamarca ");

            Random rnd49 = new Random();

            int ggdinamarca = rnd49.Next(0, 4);

            Random rnd50 = new Random();

            int ggaustralia = rnd50.Next(0, 4);


            Console.WriteLine("     Austrália: " + ggaustralia + " - " + ggdinamarca + " :Dinamarca");
            if (ggaustralia > ggdinamarca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Austrália venceu!\n");
            }
            else if (ggaustralia == ggdinamarca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggaustralia < ggdinamarca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Dinamarca venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n\n\n__________________________________________________ ");
            Console.WriteLine(" |      Group  A      | V | E | D | GM | GD | Pts | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |      Qatar         |   |   |        |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Ecuador        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Senegal        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Holanda        |   |   |   |    |    |     | ");
            Console.WriteLine(" |____________________|___|___|___|____|____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();





            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: E");
            Console.ForegroundColor = ConsoleColor.White;
         
            Console.WriteLine("\n\n     1 Rodada: Alemanha vs Japão ");

            Random rnd51 = new Random();

            int alemanha = rnd51.Next(0, 4);

            Random rnd52 = new Random();

            int japao = rnd52.Next(0, 4);


            Console.WriteLine("     Alemanha : " + alemanha + " - " + japao + " :Japão");
            if (alemanha > japao)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Alemanha venceu!\n");
            }
            else if (alemanha == japao)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (alemanha < japao)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Japão venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     2 Rodada: Espanha vs Costa Rica ");

            Random rnd53 = new Random();

            int espanha = rnd53.Next(0, 8);

            Random rnd54 = new Random();

            int costarica = rnd54.Next(0, 2);


            Console.WriteLine("     Espanha : " + espanha + " - " + costarica + " :Costa Rica");
            if (espanha > costarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Espanha venceu!\n");
            }
            else if (espanha == costarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (espanha < costarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Costa Rica venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     3 Rodada: Japão vs Costa Rica ");

            Random rnd55 = new Random();

            int gjapao = rnd55.Next(0, 4);

            Random rnd56 = new Random();

            int gcostarica = rnd56.Next(0, 3);


            Console.WriteLine("     Japão : " + gjapao + " - " + gcostarica + " :Costa Rica");
            if (gjapao > gcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Japão venceu!\n");
            }
            else if (gjapao == gcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gjapao < gcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Costa Rica venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     4 Rodada: Alemanha vs Espanha ");

            Random rnd57 = new Random();

            int gespanha = rnd57.Next(0, 4);

            Random rnd58 = new Random();

            int galemanha = rnd58.Next(0, 4);


            Console.WriteLine("     Alemanha: " + galemanha + " - " + gespanha + " :Espanha");
            if (galemanha > gespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Alemanha venceu!\n");
            }
            else if (galemanha == gespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (galemanha < gespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Espanha venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     5 Rodada: Alemanha vs Costa Rica ");

            Random rnd59 = new Random();

            int ggcostarica = rnd59.Next(0, 2);

            Random rnd60 = new Random();

            int ggalemanha = rnd60.Next(0, 4);


            Console.WriteLine("     Alemaha: " + ggalemanha + " - " + ggcostarica + " :Costa Rica");
            if (ggalemanha > ggcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Alemanha venceu!\n");
            }
            else if (ggalemanha == ggcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggalemanha < ggcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Costa Rica venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     6 Rodada: Japão vs Espanha ");

            Random rnd61 = new Random();

            int ggjapao = rnd61.Next(0, 3);

            Random rnd62 = new Random();

            int ggespanha = rnd62.Next(0, 4);


            Console.WriteLine("     Japão : " + ggjapao + " - " + ggespanha + " :Espanha");
            if (ggjapao > ggespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Japão venceu!\n");
            }
            else if (ggjapao == ggespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggjapao < ggespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Espanha venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n\n\n __________________________________________________ ");
            Console.WriteLine(" |      Group  A      | V | E | D | GM | GD | Pts | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |      Qatar         |   |   |        |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Ecuador        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Senegal        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Holanda        |   |   |   |    |    |     | ");
            Console.WriteLine(" |____________________|___|___|___|____|____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: F");
            Console.ForegroundColor = ConsoleColor.White;
     
            Console.WriteLine("\n\n     1 Rodada: Bélgica vs  Canadá");

            Random rnd63 = new Random();

            int belgica = rnd63.Next(0, 4);

            Random rnd64 = new Random();

            int canada = rnd64.Next(0, 2);


            Console.WriteLine("     Bélgica: " + belgica + " - " + canada + " :Canadá");
            if (belgica > canada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Belgica venceu!\n");
            }
            else if (belgica == canada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (belgica < canada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Canadá venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     2 Rodada: Croácia vs  Marrocos");

            Random rnd65 = new Random();

            int croacia = rnd65.Next(0, 5);

            Random rnd66 = new Random();

            int marrocos = rnd66.Next(0, 3);


            Console.WriteLine("     Croácia: " + croacia + " - " + marrocos + " :Marrocos");
            if (croacia > marrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Croácia venceu!\n");
            }
            else if (croacia == marrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (croacia < marrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Croacia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     3 Rodada: Croácia vs  Canadá");

            Random rnd67 = new Random();

            int gcroacia = rnd67.Next(0, 5);

            Random rnd68 = new Random();

            int gcanada = rnd68.Next(0, 3);


            Console.WriteLine("     Croácia: " + gcroacia + " - " + gcanada + " :Canadá");
            if (gcroacia > gcanada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Croácia venceu!\n");
            }
            else if (gcroacia == gcanada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gcroacia < gcanada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Canadá venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     4 Rodada: Bélgica vs Marrocos");

            Random rnd69 = new Random();

            int gbelgica = rnd69.Next(0, 4);

            Random rnd70 = new Random();

            int gmarrocos = rnd70.Next(0, 3);


            Console.WriteLine("     Bélgica: " + gbelgica + " - " + gmarrocos + " :Marrocos");
            if (gbelgica > gmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Belgica venceu!\n");
            }
            else if (gbelgica == gmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gbelgica < gmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Marrocos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     5 Rodada: Canadá vs Marrocos");

            Random rnd71 = new Random();

            int ggcanada = rnd71.Next(0, 4);

            Random rnd72 = new Random();

            int ggmarrocos = rnd72.Next(0, 4);


            Console.WriteLine("     Canadá: " + ggcanada + " - " + ggmarrocos + " :Marrocos");
            if (ggcanada > ggmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Canadá venceu!\n");
            }
            else if (ggcanada == ggmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggcanada < ggmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Marrocos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


    
            Console.WriteLine("\n\n     6 Rodada: Croácia vs  Bélgica");

            Random rnd73 = new Random();

            int ggcroacia = rnd73.Next(0, 4);

            Random rnd74 = new Random();

            int ggbelgica = rnd74.Next(0, 4);


            Console.WriteLine("     Croácia: " + ggcroacia + " - " + ggbelgica + " :Bélgica");
            if (ggcroacia > gcanada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Croácia venceu!\n");
            }
            else if (ggcroacia == ggbelgica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggcroacia < ggbelgica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Bélgica venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(" \n\n\n\n__________________________________________________ ");
            Console.WriteLine(" |      Group  A      | V | E | D | GM | GD | Pts | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |      Qatar         |   |   |        |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Ecuador        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Senegal        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Holanda        |   |   |   |    |    |     | ");
            Console.WriteLine(" |____________________|___|___|___|____|____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: G");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     1 Rodada: Brasil vs Sérvia");

            Random rnd75 = new Random();

            int brasil = rnd75.Next(0, 4);

            Random rnd76 = new Random();

            int servia = rnd76.Next(0, 3);


            Console.WriteLine("     Brasil: " + brasil + " - " + servia + " :sérvia");
            if (brasil > servia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Brasil venceu!\n");
            }
            else if (brasil == servia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (brasil < servia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Sérvia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     2 Rodada: Suíça vs Camarões");

            Random rnd77 = new Random();

            int suica = rnd77.Next(0, 3);

            Random rnd78 = new Random();

            int camaroes = rnd78.Next(0, 2);


            Console.WriteLine("     Suíça: " + suica + " - " + camaroes + " :servia");
            if (suica > camaroes)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Suíça venceu!\n");
            }
            else if (suica == camaroes)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (suica < camaroes)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Camarões venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     3 Rodada: Brasil vs Suíça");

            Random rnd79 = new Random();

            int gbrasil = rnd79.Next(0, 5);

            Random rnd80 = new Random();

            int gsuica = rnd80.Next(0, 3);


            Console.WriteLine("     Brasil: " + gbrasil + " - " + gsuica + " :Suíça");
            if (gbrasil > gsuica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Brasil venceu!\n");
            }
            else if (gbrasil == gsuica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gbrasil < gsuica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Suíça venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


      
            Console.WriteLine("\n\n     4 Rodada: Camarões vs Sérvia");

            Random rnd81 = new Random();

            int gcamaroes = rnd81.Next(0, 3);

            Random rnd82 = new Random();

            int gservia = rnd82.Next(0, 3);


            Console.WriteLine("     Camarões: " + gcamaroes + " - " + gservia + " :Sérvia");
            if (gcamaroes > gservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Camarões venceu!\n");
            }
            else if (gcamaroes == gservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gcamaroes < gservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Sérvia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


 
            Console.WriteLine("\n\n     5 Rodada: Camarões vs Brasil");

            Random rnd83 = new Random();

            int ggcamaroes = rnd83.Next(0, 3);

            Random rnd84 = new Random();

            int ggbrasil = rnd84.Next(0, 5);


            Console.WriteLine("     Camarões: " + ggcamaroes + " - " + ggbrasil + " :Brasil");
            if (ggcamaroes > ggbrasil)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Camarões venceu!\n");
            }
            else if (ggcamaroes == ggbrasil)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggcamaroes < ggbrasil)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     brasil venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     6 Rodada: Suíça vs Sérvia");

            Random rnd85 = new Random();

            int ggsuica = rnd85.Next(0, 3);

            Random rnd86 = new Random();

            int ggservia = rnd86.Next(0, 3);


            Console.WriteLine("     Suíça: " + ggsuica + " - " + ggservia + " :Sérvia");
            if (ggsuica > ggservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Suíça venceu!\n");
            }
            else if (ggsuica == ggservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggsuica < ggservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Sérvia venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(" \n\n\n\n__________________________________________________ ");
            Console.WriteLine(" |      Group  A      | V | E | D | GM | GD | Pts | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |      Qatar         |   |   |        |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Ecuador        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Senegal        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Holanda        |   |   |   |    |    |     | ");
            Console.WriteLine(" |____________________|___|___|___|____|____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: H");
            Console.ForegroundColor = ConsoleColor.White;
       


            Console.WriteLine("\n\n     1 Rodada: Portugal vs Gana");

            Random rnd87 = new Random();

            int portugal = rnd87.Next(0, 4);

            Random rnd88 = new Random();

            int gana = rnd88.Next(0, 3);

            Console.WriteLine("     Portugal: " + portugal + " - " + gana + " :Gana");
            if (portugal > gana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Portugal venceu!\n");
            }
            else if (portugal == gana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (portugal < gana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Gana venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     2 Rodada: Urguai vs Coreia do Sul");

            Random rnd89 = new Random();

            int uruguai = rnd89.Next(0, 5);

            Random rnd90 = new Random();

            int coreiasul = rnd90.Next(0, 3);


            Console.WriteLine("     Uruguai: " + uruguai + " - " + coreiasul + " :coreia do sul");
            if (uruguai > coreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Uruguai venceu!\n");
            }
            else if (uruguai == coreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (uruguai < coreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Coreia do sul venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


    
            Console.WriteLine("\n\n     3 Rodada: Portugal vs Uruguai");

            Random rnd91 = new Random();

            int guruguai = rnd91.Next(0, 4);

            Random rnd92 = new Random();

            int gportugal = rnd92.Next(0, 4);


            Console.WriteLine("     Portugal: " + gportugal + " - " + guruguai + " :Uruguai");
            if (gportugal > guruguai)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Portugal venceu!\n");
            }
            else if (gportugal == guruguai)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gportugal < guruguai)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Uruguai venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     4 Rodada: Gana vs Coreia do Sul");

            Random rnd93 = new Random();

            int ggana = rnd93.Next(0, 4);

            Random rnd94 = new Random();

            int gcoreiasul = rnd94.Next(0, 4);


            Console.WriteLine("     Gana: " + ggana + " - " + gcoreiasul + " :Coreia do Sul");
            if (gcoreiasul > ggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Coreia do sul venceu!\n");
            }
            else if (gcoreiasul == ggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gcoreiasul < ggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Gana venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


     
            Console.WriteLine("\n\n     5 Rodada: Uruguai vs Gana");


            Random rnd95 = new Random();

            int gguruguai = rnd95.Next(0, 5);

            Random rnd96 = new Random();

            int gggana = rnd96.Next(0, 4);

            Console.WriteLine("     Uruguai: " + gguruguai + " - " + gggana + " :Gana");
            if (gguruguai > gggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Uruguai venceu!\n");
            }
            else if (gguruguai == gggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gguruguai < gggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Gana venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


        
            Console.WriteLine("\n\n     6 Rodada: Portugal vs coreia do sul");


            Random rnd97 = new Random();

            int ggportugal = rnd97.Next(0, 4);

            Random rnd98 = new Random();

            int ggcoreiasul = rnd98.Next(0, 3);

            Console.WriteLine("     Portugal: " + ggportugal + " - " + ggcoreiasul + " :Coreia do Sul");
            if (ggportugal > ggcoreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Portugal venceu!\n");
            }
            else if (ggportugal == ggcoreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggportugal < ggcoreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Coreia do Sul venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(" \n\n\n\n__________________________________________________ "_____ ");
            Console.WriteLine(" |      Group  A      | V | E | D | GM | GD | Pts | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |      Qatar         |   |   |        |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Ecuador        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Senegal        |   |   |   |    |    |     | ");
            Console.WriteLine(" |--------------------|---|---|---|----|----|-----| ");
            Console.WriteLine(" |     Holanda        |   |   |   |    |    |     | ");
            Console.WriteLine(" |____________________|___|___|___|____|____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();





        }
    }
}
